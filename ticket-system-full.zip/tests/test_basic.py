import os
import tempfile
import pytest
from app import app as flask_app, engine, Base
from sqlalchemy.orm import sessionmaker

@pytest.fixture
def client():
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
    # create fresh DB
    Base.metadata.create_all(engine)
    flask_app.config['TESTING'] = True
    with flask_app.test_client() as client:
        yield client
    os.close(db_fd)
    os.unlink(db_path)

def test_index(client):
    rv = client.get('/')
    assert rv.status_code == 200
    assert b'TicketSys' in rv.data
